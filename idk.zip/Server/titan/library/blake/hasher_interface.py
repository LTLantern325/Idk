"""
Python conversion of generic hasher interface
Base hasher interface for all hash algorithms
"""

from abc import ABC, abstractmethod
from typing import Optional

class IHasher(ABC):
    """Generic hasher interface"""

    @abstractmethod
    def update(self, data: bytes) -> None:
        """Update hash with data"""
        pass

    @abstractmethod
    def finish(self) -> bytes:
        """Get final hash"""
        pass

    @abstractmethod
    def reset(self) -> None:
        """Reset hasher"""
        pass

    @abstractmethod
    def get_hash_size(self) -> int:
        """Get hash output size"""
        pass

    def compute_hash(self, data: bytes) -> bytes:
        """Compute hash of data"""
        self.reset()
        self.update(data)
        return self.finish()

class GenericHasher(IHasher):
    """Generic hasher implementation"""

    def __init__(self, hash_size: int = 32):
        """Initialize generic hasher"""
        self.hash_size = hash_size
        self.data = bytearray()

    def update(self, data: bytes) -> None:
        """Update with data"""
        self.data.extend(data)

    def finish(self) -> bytes:
        """Get final hash"""
        import hashlib

        if self.hash_size <= 32:
            hasher = hashlib.sha256()
        else:
            hasher = hashlib.sha512()

        hasher.update(bytes(self.data))
        digest = hasher.digest()

        # Truncate or pad to desired size
        if len(digest) > self.hash_size:
            return digest[:self.hash_size]
        elif len(digest) < self.hash_size:
            return digest + b' ' * (self.hash_size - len(digest))
        else:
            return digest

    def reset(self) -> None:
        """Reset hasher"""
        self.data = bytearray()

    def get_hash_size(self) -> int:
        """Get hash size"""
        return self.hash_size
