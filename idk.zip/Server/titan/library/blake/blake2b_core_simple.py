"""
Python conversion of Blake2B simple core (simplified)
Simple Blake2B core implementation
"""

from .blake2b_core import Blake2BCore
from typing import List

class Blake2BCoreSimple(Blake2BCore):
    """Simple Blake2B core implementation"""

    @staticmethod
    def hash(config: List[int], data: bytes, output_size: int) -> bytes:
        """Simple hash function"""
        # Initialize state
        state = Blake2BCoreSimple.initialize_state(config)

        # Process data in blocks
        offset = 0
        counter = 0

        while offset < len(data):
            block_size = min(Blake2BCore.BLOCK_SIZE_BYTES, len(data) - offset)
            block = data[offset:offset + block_size]

            # Pad block if necessary
            if len(block) < Blake2BCore.BLOCK_SIZE_BYTES:
                block = block + b' ' * (Blake2BCore.BLOCK_SIZE_BYTES - len(block))

            counter += block_size
            is_final = offset + block_size >= len(data)

            Blake2BCore.compress(state, block, counter, is_final)
            offset += block_size

        # Finalize
        output = bytearray(output_size)
        Blake2BCore.finalize(state, output, output_size)
        return bytes(output)

    @staticmethod
    def hash_with_key(config: List[int], key: bytes, data: bytes, output_size: int) -> bytes:
        """Hash with key"""
        if not key:
            return Blake2BCoreSimple.hash(config, data, output_size)

        # Pad key to block size
        key_block = key + b' ' * (Blake2BCore.BLOCK_SIZE_BYTES - len(key))

        # Prepend key block to data
        keyed_data = key_block + data

        return Blake2BCoreSimple.hash(config, keyed_data, output_size)
