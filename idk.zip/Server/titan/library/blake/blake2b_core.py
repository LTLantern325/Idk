"""
Python conversion of Blake2B core functionality (simplified)
Core Blake2B implementation
"""

import struct
from typing import List

class Blake2BCore:
    """Blake2B core implementation"""

    # Blake2B constants
    BLOCK_SIZE_BYTES = 128
    ROUNDS = 12

    # IV constants (first 64 bits of fractional parts of square roots of primes 2, 3, 5, 7, 11, 13, 17, 19)
    IV = [
        0x6a09e667f3bcc908, 0xbb67ae8584caa73b, 0x3c6ef372fe94f82b, 0xa54ff53a5f1d36f1,
        0x510e527fade682d1, 0x9b05688c2b3e6c1f, 0x1f83d9abfb41bd6b, 0x5be0cd19137e2179
    ]

    @staticmethod
    def bytes_to_uint64(data: bytes, offset: int) -> int:
        """Convert 8 bytes to uint64 (little endian)"""
        if offset + 8 > len(data):
            return 0
        return struct.unpack('<Q', data[offset:offset+8])[0]

    @staticmethod
    def uint64_to_bytes(value: int, output: bytearray, offset: int) -> None:
        """Convert uint64 to 8 bytes (little endian)"""
        packed = struct.pack('<Q', value & 0xFFFFFFFFFFFFFFFF)
        output[offset:offset+8] = packed

    @staticmethod
    def initialize_state(config: List[int]) -> List[int]:
        """Initialize Blake2B state"""
        state = list(Blake2BCore.IV)

        # XOR first 8 state words with config
        for i in range(min(8, len(config))):
            state[i] ^= config[i]

        return state

    @staticmethod
    def compress(state: List[int], block: bytes, counter: int, final_block: bool) -> None:
        """Compress a block (simplified)"""
        # This is a greatly simplified version
        # Real implementation would do the full Blake2B compression

        # Convert block to words
        words = []
        for i in range(0, len(block), 8):
            if i + 8 <= len(block):
                words.append(Blake2BCore.bytes_to_uint64(block, i))
            else:
                # Pad incomplete word
                padded = block[i:] + b' ' * (8 - (len(block) - i))
                words.append(Blake2BCore.bytes_to_uint64(padded, 0))

        # Simplified mixing (not cryptographically correct)
        for i in range(len(state)):
            if i < len(words):
                state[i] ^= words[i]
                state[i] = Blake2BCore._rotate_right(state[i], 32)
                state[i] ^= counter

    @staticmethod
    def _rotate_right(value: int, bits: int) -> int:
        """Rotate 64-bit value right"""
        value &= 0xFFFFFFFFFFFFFFFF
        return ((value >> bits) | (value << (64 - bits))) & 0xFFFFFFFFFFFFFFFF

    @staticmethod
    def finalize(state: List[int], output: bytearray, output_size: int) -> None:
        """Finalize hash and write to output"""
        offset = 0
        for i in range(len(state)):
            if offset >= output_size:
                break
            Blake2BCore.uint64_to_bytes(state[i], output, offset)
            offset += 8
